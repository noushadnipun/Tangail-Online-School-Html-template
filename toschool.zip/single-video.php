<?php include 'header.php'; ?>
<section class="mt-2">

<div class="row">
	<div class="col-md-9 mb-3">
		<div class="bg-white p-3">
			<h3 class="text-dark pb-2">শ্রেণি ভিত্তিক ক্লাশ সমূহ</h3>
			<div class="pb-4">
				<div class="embed-responsive embed-responsive-16by9">
  					<iframe class="embed-responsive-item" src="https://www.youtube.com/embed/dhnW1XmQS3s" allowfullscreen></iframe>
				</div>
			</div>
		</div>
		
	</div>
	<div class="col-md-3 mb-3">
		<?php include 'sidebar.php'; ?>
	</div>
</div>


</section>
<?php include 'footer.php'; ?>
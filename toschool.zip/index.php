<?php include 'header.php' ?>

<?php include 'homepage/slider.php'; ?>
<?php include 'homepage/subject-grid.php'; ?>	
<?php include 'homepage/news-block.php'; ?>	
<?php include 'homepage/photo-gallery.php'; ?>	

<?php include 'footer.php' ?>